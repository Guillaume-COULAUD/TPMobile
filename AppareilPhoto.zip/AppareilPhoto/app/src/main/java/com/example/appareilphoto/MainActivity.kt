package com.example.appareilphoto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ImageView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
const val REQUEST_CODE = 200
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_TEXT)
        val imageView = findViewById<ImageView>(R.id.image1)
        if ( uri != null) imageView.setImageURI(uri)


        if (askForPermissions()) {
            val boutonGallerie = findViewById<Button>(R.id.bouton1)
            boutonGallerie.setOnClickListener {
                val intent = Intent(this@MainActivity, GallerieActivity::class.java)
                startActivity(intent)
            }
        }
    }



    fun isPermissionsAllowed(): Boolean {
        Boolean
        return if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            false
        }
        else true
    }

    fun askForPermissions(): Boolean{
        if (!isPermissionsAllowed()){
            if (ActivityCompat.shouldShowRequestPermissionRationale(this as Activity, Manifest.permission.READ_EXTERNAL_STORAGE)
                || ActivityCompat.shouldShowRequestPermissionRationale(this as Activity, Manifest.permission.CAMERA)){
                showPermissionDeniedDialog()
            } else{
                ActivityCompat.requestPermissions(this as Activity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                    , REQUEST_CODE)
            }
            return false
        }
        return true
    }

    fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
                .setTitle("Permission Denied")
                .setMessage("Permission is denied, Please allow permissions from App Settings.")
                .setPositiveButton("App Settings",
                        DialogInterface.OnClickListener{ dialogInterface, i ->
                            val intent= Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts("package", getPackageName(),null)
                            intent.data = uri
                            startActivity(intent)
                        })
                .setNegativeButton("Cancel", null)
                .show()
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<String>,gantResults:IntArray) {
        when (requestCode) {
            REQUEST_CODE -> {
                if (gantResults.size > 0 && gantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(this@MainActivity, MainActivity::class.java)
                    startActivity(intent)
                }
                else {
                    askForPermissions()
                }
                return
            }
        }
    }

}