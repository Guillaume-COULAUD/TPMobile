package com.example.listview

class Livre ( var titre : String, var image : String){

}



