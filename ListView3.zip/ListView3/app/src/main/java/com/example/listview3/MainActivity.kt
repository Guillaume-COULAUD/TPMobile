package com.example.listview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.example.listview3.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var strings : Array<String> = arrayOf("Star wars","Top Gun","harry potter", "very bad trip" , "Film 5") // création et initialisation du tableau
        var liste : ListView = findViewById<ListView>(R.id.liste1) // récupération de la ListView
        var livre_Premier = Livre("Loann", "https://www.nature-isere.fr/sites/default/files/styles/natureisere_large/public/images/temoignages/principale/iceland-2111810_1920.jpg?itok=PMXb-dCB")
        var livre_Second = Livre("Léo", "https://blog-fr.orson.io/wp-content/uploads/2017/06/9-4.jpg")
        var livre_Troisieme = Livre("Guillaume", "https://www.google.com/url?sa=i&url=https%3A%2F%2Fecodev.ch%2F2019%2F06%2Fcomment-trouver-des-images-libres-de-droits-mon-archive-best-of-de-openclipart%2F&psig=AOvVaw12xhPKu7Gxj-s5wuv53sNW&ust=1615541096368000&source=images&cd=vfe&ved=0CAMQjRxqFwoTCMjNudH1p-8CFQAAAAAdAAAAABAU")

        var liste_Livre = ArrayList<Livre>();
        liste_Livre.add(0, livre_Premier)
        liste_Livre.add(1, livre_Second)
        liste_Livre.add(2, livre_Troisieme)



        val adaptater: ArrayAdapter<String> = ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            android.R.id.text1,
            strings
        )

        liste.adapter = adaptater

        liste.setOnItemClickListener { parent, liste, position, id ->
            val element : String = parent.getItemAtPosition(position).toString() //l'item sur lequel on clique
            Toast.makeText ( this, "Titre : $element", Toast.LENGTH_SHORT).show() // affichage de l'item cliqué
        }

        //création de l'adaptateur du livre
        val livre_adapter: LivreAdapter = LivreAdapter(
            liste_Livre, // liste créé plutot
            this
        )

        liste.adapter = livre_adapter //affichage de la liste



    }
}
